package wei;
import javax.swing.*;


import java.net.URL;

public class Date  {
    public static URL upUrl=Date.class.getResource("/ziyuan/up.png");
    public static URL downUrl=Date.class.getResource("/ziyuan/down.png");
    public static URL leftUrl=Date.class.getResource("/ziyuan/left.png");
    public static URL rightUrl=Date.class.getResource("/ziyuan/right.png");
    public static ImageIcon up=new ImageIcon(upUrl);
    public static ImageIcon down=new ImageIcon(downUrl);
    public static ImageIcon left=new ImageIcon(leftUrl);
    public static ImageIcon right=new ImageIcon(rightUrl);
    public static URL bodyurl=Date.class.getResource("/ziyuan/body.png");
    public static ImageIcon body=new ImageIcon(bodyurl);
    public static URL foodurl=Date.class.getResource("/ziyuan/food.png");
    public static   ImageIcon food=new ImageIcon(foodurl);

}